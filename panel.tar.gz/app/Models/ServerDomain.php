<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property int $id
 * @property int $server_id
 * @property string $domain
 * @property int|null $target_port
 * @property \Carbon\Carbon $created_at
 * @property \Carbon\Carbon $updated_at
 * @property \Pterodactyl\Models\Server $server
 */
class ServerDomain extends Model
{
    /**
     * The resource name for this model when outputting via JSON.
     */
    public const RESOURCE_NAME = 'server_domain';

    /**
     * The table associated with the model.
     */
    protected $table = 'server_domains';

    /**
     * Fields that are mass assignable.
     */
    protected $fillable = [
        'server_id',
        'domain',
        'cname_code',
        'target_port',
    ];

    /**
     * Rules to validate data against.
     */
    public static array $validationRules = [
        'server_id' => 'required|numeric|exists:servers,id',
        'domain' => 'required|string|max:191',
        'target_port' => 'nullable|numeric|between:1,65535',
    ];

    /**
     * Returns the server this domain belongs to.
     */
    public function server(): BelongsTo
    {
        return $this->belongsTo(Server::class);
    }
}
