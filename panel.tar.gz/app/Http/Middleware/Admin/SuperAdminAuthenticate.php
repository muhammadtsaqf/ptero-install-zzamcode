<?php

namespace Pterodactyl\Http\Middleware\Admin;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class SuperAdminAuthenticate
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next): mixed
    {
        $user = $request->user();
        if (!$user || (!$user->super_admin && !$user->root_admin)) {
            throw new AccessDeniedHttpException('This action requires Administrator privileges.');
        }

        return $next($request);
    }
}
