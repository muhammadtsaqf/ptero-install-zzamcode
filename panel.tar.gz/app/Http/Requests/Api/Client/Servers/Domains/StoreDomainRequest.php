<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Domains;

use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

class StoreDomainRequest extends ClientApiRequest
{
    /**
     * Check that the user has permission to create allocations/domains for this server.
     */
    public function permission(): string
    {
        return Permission::ACTION_ALLOCATION_CREATE;
    }

    /**
     * Rules to validate domain creation requests.
     */
    public function rules(): array
    {
        return [
            'domain' => [
                'required',
                'string',
                'max:191',
                'regex:/^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/',
                'unique:server_domains,domain',
            ],
            'target_port' => 'nullable|integer|between:1,65535',
        ];
    }

    /**
     * Custom validation error messages.
     */
    public function messages(): array
    {
        return [
            'domain.regex' => 'The domain format is invalid. Example: app.yourdomain.com',
            'domain.unique' => 'This domain is already mapped or in use.',
        ];
    }
}
