<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Domains;

use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

class DeleteDomainRequest extends ClientApiRequest
{
    /**
     * Check that the user has permission to delete allocations/domains for this server.
     */
    public function permission(): string
    {
        return Permission::ACTION_ALLOCATION_DELETE;
    }
}
