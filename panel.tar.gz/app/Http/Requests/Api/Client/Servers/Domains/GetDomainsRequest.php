<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Domains;

use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

class GetDomainsRequest extends ClientApiRequest
{
    /**
     * Check that the user has permission to view allocation/network domain mappings.
     */
    public function permission(): ?string
    {
        return Permission::ACTION_ALLOCATION_READ;
    }
}
