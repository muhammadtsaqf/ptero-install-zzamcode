<?php

namespace Pterodactyl\Http\ViewComposers;

use Illuminate\View\View;
use Pterodactyl\Services\Helpers\AssetHashService;

class AssetComposer
{
    /**
     * AssetComposer constructor.
     */
    public function __construct(private AssetHashService $assetHashService)
    {
    }

    /**
     * Provide access to the asset service in the views.
     */
    public function compose(View $view): void
    {
        $view->with('asset', $this->assetHashService);
        $view->with('siteConfiguration', [
            'name' => config('app.name') ?? 'zzamcode panel',
            'locale' => config('app.locale') ?? 'en',
            'recaptcha' => [
                'enabled' => filter_var(config('recaptcha.enabled', false), FILTER_VALIDATE_BOOLEAN),
                'provider' => config('recaptcha.provider', 'recaptcha'),
                'siteKey' => config('recaptcha.website_key') ?? '',
            ],
            'logo' => config('app.logo') ?? '/assets/svgs/pterodactyl.svg',
            'registration' => (bool) config('app.registration', false),
        ]);
    }
}
