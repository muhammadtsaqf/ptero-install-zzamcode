<?php

namespace Pterodactyl\Http\Controllers\Api\Bot;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonPowerRepository;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Support\Str;

use Pterodactyl\Models\Node;
use Pterodactyl\Models\StoreDiscount;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;

class WebhookController extends Controller
{
    public function __construct(
        private DaemonPowerRepository $powerRepository,
        private SettingsRepositoryInterface $settings
    ) {
    }

    public function handle(Request $request): JsonResponse
    {
        // Simple security check
        $secret = env('WA_BOT_SECRET', 'pterodactyl_wa_secret');
        if ($request->input('secret') !== $secret) {
            return response()->json(['reply' => 'Unauthorized access.'], 401);
        }

        $rawMessage = trim($request->input('message'));
        if (!$phone || !$rawMessage) {
            return response()->json(['reply' => 'Invalid payload.'], 400);
        }

        // Handle Prefix Logic:
        // 1. If starts with '.', strip it (e.g. '.mysrv' -> 'mysrv')
        // 2. If starts with any other non-alphanumeric prefix (like '!', '/', '#', '$', etc.), ignore it! Only '.' prefix is allowed if prefix is used.
        // 3. If starts with letters/digits (no prefix), support it directly (e.g. 'mysrv' -> 'mysrv').
        $message = $rawMessage;
        if (str_starts_with($rawMessage, '.')) {
            $message = trim(substr($rawMessage, 1));
        } else if (preg_match('/^[^\w\s]/u', $rawMessage)) {
            // Started with a symbol other than '.' (e.g. !help, /menu, #servers) -> Reject/Ignore
            return response()->json(['success' => true]);
        }
        
        $messageLower = strtolower($message);

        // Clean incoming phone (remove +, -, spaces, etc)
        $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
        
        // Normalize international country codes (e.g. 628 -> 08, 08 -> 628, 812 -> 62812)
        $phoneVariants = [$cleanPhone];
        if (str_starts_with($cleanPhone, '62')) {
            $phoneVariants[] = '0' . substr($cleanPhone, 2);
            $phoneVariants[] = substr($cleanPhone, 2); // without 62 (e.g. 831...)
        } elseif (str_starts_with($cleanPhone, '0')) {
            $phoneVariants[] = '62' . substr($cleanPhone, 1);
            $phoneVariants[] = substr($cleanPhone, 1); // without 0 (e.g. 831...)
        } elseif (str_starts_with($cleanPhone, '8')) {
            $phoneVariants[] = '62' . $cleanPhone;
            $phoneVariants[] = '0' . $cleanPhone;
        }

        // Fetch users that might match
        $users = User::whereNotNull('phone')->get();
        $user = $users->first(function($u) use ($phoneVariants) {
            $dbPhone = preg_replace('/[^0-9]/', '', $u->phone);
            if (empty($dbPhone)) return false;

            // Generate variants for DB phone as well
            $dbVariants = [$dbPhone];
            if (str_starts_with($dbPhone, '62')) {
                $dbVariants[] = '0' . substr($dbPhone, 2);
                $dbVariants[] = substr($dbPhone, 2);
            } elseif (str_starts_with($dbPhone, '0')) {
                $dbVariants[] = '62' . substr($dbPhone, 1);
                $dbVariants[] = substr($dbPhone, 1);
            } elseif (str_starts_with($dbPhone, '8')) {
                $dbVariants[] = '62' . $dbPhone;
                $dbVariants[] = '0' . $dbPhone;
            }

            return !empty(array_intersect($phoneVariants, $dbVariants));
        });

        if (!$user) {
            return response()->json(['reply' => "❌ Nomor WhatsApp Anda ({$cleanPhone}) belum terdaftar di panel.\n\nSilakan login ke panel dan update kolom Phone Number di Account Overview menjadi nomor Anda ini."]);
        }

        $botName = strtoupper($this->settings->get('wa_bot:bot_name', config('app.name', 'ZZAMCODE BOT')));

        $ownerNumber = preg_replace('/[^0-9]/', '', $this->settings->get('wa_bot:owner_number', ''));
        $ownerVariants = [];
        if (!empty($ownerNumber)) {
            $ownerVariants[] = $ownerNumber;
            if (str_starts_with($ownerNumber, '62')) {
                $ownerVariants[] = '0' . substr($ownerNumber, 2);
                $ownerVariants[] = substr($ownerNumber, 2);
            } elseif (str_starts_with($ownerNumber, '0')) {
                $ownerVariants[] = '62' . substr($ownerNumber, 1);
                $ownerVariants[] = substr($ownerNumber, 1);
            } elseif (str_starts_with($ownerNumber, '8')) {
                $ownerVariants[] = '62' . $ownerNumber;
                $ownerVariants[] = '0' . $ownerNumber;
            }
        }
        $isOwner = !empty($ownerVariants) && !empty(array_intersect($phoneVariants, $ownerVariants));

        // Enforce Group-Only mode
        $remoteJid = $request->input('remoteJid', '');
        $groupJid = $this->settings->get('wa_bot:group_jid', '');
        $isGroupMessage = str_contains($remoteJid, '@g.us');
        
        // Hanya owner yang bisa private
        if (!$isGroupMessage && !$isOwner) {
            $parts = explode(' ', $message);
            $command = $parts[0] ?? '';
            if (in_array($command, ['mysrv', 'servers', 'list', 'start', 'stop', 'restart', 'kill', 'help', 'menu'])) {
                return response()->json(['reply' => "⚠️ Bot saat ini hanya melayani perintah di dalam Grup resmi.\nAnda tidak dapat menggunakannya di *Private Chat*."]);
            }
            return response()->json(['success' => true]); // Ignore silently
        }
        
        // Jika sudah gabung ke satu grup, abaikan grup lain
        if ($isGroupMessage && $groupJid !== '' && $remoteJid !== $groupJid) {
            return response()->json(['success' => true]);
        }

        $parts = explode(' ', $message);
        $command = $parts[0];
        $target = trim(substr($message, strlen($command))) ?: null;

        if ($command === 'mysrv' || $command === 'servers' || $command === 'list') {
            if ($target && in_array(explode(' ', $target)[0], ['start', 'stop', 'restart', 'kill', 'reinstall', 'createbackup', 'backup'])) {
                $subArgs = explode(' ', $target);
                $subCommand = $subArgs[0];
                $serverId = $subArgs[1] ?? null;

                if (!$serverId) {
                    return response()->json(['reply' => "⚠️ Format salah. Contoh: `mysrv {$subCommand} 453` atau `.mysrv {$subCommand} 453`"]);
                }

                $server = Server::where('id', $serverId)
                                ->where('owner_id', $user->id)
                                ->first();

                if (!$server) {
                    return response()->json(['reply' => "❌ Server dengan ID `{$serverId}` tidak ditemukan atau bukan milik Anda."]);
                }

                try {
                    if (in_array($subCommand, ['start', 'stop', 'restart', 'kill'])) {
                        $this->powerRepository->setServer($server)->send($subCommand);
                        return response()->json([
                            'reply' => "⚡ *{$botName} POWER CONTROL* ⚡\n\n" .
                                       "✅ Perintah *{$subCommand}* kasil dikirim!\n" .
                                       "📌 Target Server: *{$server->name}*\n" .
                                       "🆔 ID Server: `{$server->id}`"
                        ]);
                    } elseif ($subCommand === 'reinstall') {
                        app(\Pterodactyl\Repositories\Eloquent\ServerRepository::class)->update($server->id, ['status' => Server::STATUS_INSTALLING]);
                        return response()->json([
                            'reply' => "🛠️ *REINSTALL SERVER PROCESS* 🛠️\n\n" .
                                       "✅ Proses reinstall kanggo server *{$server->name}* wis diwiwiti.\n" .
                                       "⏳ Server ora bisa diakses sawetara wektu nganti proses rampung."
                        ]);
                    } elseif ($subCommand === 'createbackup') {
                        return response()->json(['reply' => "⏳ Fitur *create backup* via WhatsApp bakal engal kasedhiya!"]);
                    } elseif ($subCommand === 'backup') {
                        return response()->json(['reply' => "⏳ Fitur *send backup* via WhatsApp bakal engal kasedhiya!"]);
                    }
                } catch (\Exception $e) {
                    return response()->json(['reply' => "❌ Gagal ngirim perintah menyang server. Error: " . $e->getMessage()]);
                }
            }

            $servers = Server::with('node')->where('owner_id', $user->id)->get();
            if ($servers->isEmpty()) {
                return response()->json([
                    'reply' => "━━━━━━━━━━━━━━━━━━━━━━\n" .
                               "🎮 *SERVER MANAGEMENT* 🎮\n" .
                               "━━━━━━━━━━━━━━━━━━━━━━\n\n" .
                               "Sampeyan durung nduweni server ing panel."
                ]);
            }

            $reply = "╭━━━⚙️ *CONTROL SERVER OPTIONS* ⚙️━━━╮\n" .
                     "┃ 1. 🟢 Start    : `mysrv start [id]`\n" .
                     "┃ 2. 🔄 Restart  : `mysrv restart [id]`\n" .
                     "┃ 3. 🔴 Stop     : `mysrv stop [id]`\n" .
                     "┃ 4. 🛠️ Reinstall: `mysrv reinstall [id]`\n" .
                     "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n" .
                     "💡 *Info:* Perintah bisa tanpa prefix utawa nggunakake prefix `.` (tuladha: `mysrv` / `.mysrv`)\n\n" .
                     "📋 *DAFTAR SERVER SAMPEYAN:*\n" .
                     "─────────────────────────\n";

            foreach ($servers as $idx => $srv) {
                $expired = "Permanen";
                if (isset($srv->store_expires_at) && $srv->store_expires_at) {
                    $expired = \Carbon\Carbon::parse($srv->store_expires_at)->translatedFormat('d F Y');
                }
                
                $status = "🟢 Aktif";
                if ($srv->isSuspended()) $status = "🔴 Suspended";
                elseif (!$srv->isInstalled()) $status = "🟡 Installing";

                $backupStatus = ($srv->backup_limit > 0) ? "✅ Aktif" : "❌ Nonaktif";

                $reply .= "📌 *ID Server*: `{$srv->id}`\n" .
                          "📛 *Nama*: *{$srv->name}*\n" .
                          "⏳ *Expired*: {$expired}\n" .
                          "📊 *Status*: {$status}\n" .
                          "🔄 *Backup*: {$backupStatus}\n" .
                          "─────────────────────────\n";
            }
            $reply .= "✨ *Total*: `{$servers->count()}` server kasedhiya.";
            return response()->json(['reply' => $reply, 'simulateProgress' => true]);
        }

        if ($command === 'help' || $command === 'menu') {
            $reply = "╭━━━🤖 *{$botName} ASSISTANT* 🤖━━━╮\n" .
                     "┃ Sugeng rawuh ing WhatsApp Bot Panel!\n" .
                     "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n" .
                     "📌 *PERINTAH UMUM (USER):*\n" .
                     "• `menu` / `help` — Nampilake menu panduan iki\n" .
                     "• `mysrv` / `servers` — Nampilake daftar server & opsi kontrol\n" .
                     "• `mysrv start [id]` — Menyalakan server\n" .
                     "• `mysrv restart [id]` — Me-restart server\n" .
                     "• `mysrv stop [id]` — Mematikan server\n" .
                     "• `mysrv reinstall [id]` — Reinstall ulang server\n\n" .
                     "✨ *Fitur Bot:* Tanpa prefix utawa nganggo prefix `.`\n" .
                     "⚡ *Powered by {$botName} System*";
            return response()->json(['reply' => $reply, 'simulateProgress' => true]);
        }

        // =====================================
        // BOT OWNER COMMANDS
        // =====================================

        if (in_array($command, ['menuowner', 'creatediscount', 'join', 'setgroup', 'info', 'broadcast', 'restartbot'])) {
            if (!$isOwner) {
                return response()->json(['reply' => "❌ Anda tidak memiliki izin untuk menggunakan perintah ini."]);
            }

            if ($command === 'menuowner') {
                $reply = "👑 ━━━ *EXECUTIVE OWNER CONTROL* ━━━ 👑\n\n" .
                         "⚙️ *PERINTAH OWNER PANEL:*\n" .
                         "• `creatediscount <code> <percent> <max_uses>`\n" .
                         "  └> *Gawe kode diskon store anyar*\n" .
                         "• `join <link_grup>`\n" .
                         "  └> *Gabung bot menyang grup WA*\n" .
                         "• `setgroup`\n" .
                         "  └> *Setel grup utama kanggo notifikasi bot*\n" .
                         "• `info`\n" .
                         "  └> *Tampilake statistik sistem panel*\n" .
                         "• `broadcast <pesan>`\n" .
                         "  └> *Kirim pesan massal menyang kabeh user*\n" .
                         "• `restartbot`\n" .
                         "  └> *Restart proses daemon PM2 bot*\n\n" .
                         "⚡ *{$botName} ADMIN CONSOLE*";
                return response()->json(['reply' => $reply, 'simulateProgress' => true]);
            }

            if ($command === 'creatediscount') {
                $args = explode(' ', $target);
                if (count($args) < 3) {
                    return response()->json([
                        'reply' => "⚠️ *Format Salah!*\n\nContoh: `creatediscount DISKON50 50 100`"
                    ]);
                }
                
                $code = strtoupper($args[0]);
                $percent = (int)$args[1];
                $maxUses = (int)$args[2];

                StoreDiscount::create([
                    'code' => $code,
                    'discount_percent' => $percent,
                    'max_uses' => $maxUses,
                    'uses' => 0
                ]);

                // Broadcast to group
                $broadcastMsg = "🎉 *PROMO KODE DISKON STORE!* 🎉\n\n" .
                                "Oleh diskon *{$percent}%* kanggo tuku server ing Store Panel!\n\n" .
                                "👉 Kode Voucher: *{$code}*\n" .
                                "⏳ Kuota Pemakaian: *{$maxUses}x*\n\n" .
                                "🔥 Ayo langsung dingo sadurunge entek!";
                app(\Pterodactyl\Services\WhatsApp\WhatsAppNotifierService::class)->sendToGroup($broadcastMsg);

                return response()->json([
                    'reply' => "✅ *KODE DISKON SUKSES DIBUAT!*\n\n" .
                               "📌 Kode: *{$code}*\n" .
                               "🏷️ Diskon: *{$percent}%*\n" .
                               "👥 Maksimal Kuota: *{$maxUses}x*"
                ]);
            }

            if ($command === 'join') {
                if (!$target || !str_contains($target, 'chat.whatsapp.com/')) {
                    return response()->json(['reply' => "⚠️ Format salah. Kirimkan link invite WhatsApp grup."]);
                }

                $currentGroup = $this->settings->get('wa_bot:group_jid', '');
                if ($currentGroup !== '') {
                    return response()->json(['reply' => "❌ Bot wis ana ing njero grup liya.\nBot mung bisa join 1 grup. Keluarkan bot saka grup saiki dhisik."]);
                }

                $inviteCode = explode('chat.whatsapp.com/', $target)[1];
                $inviteCode = explode(' ', $inviteCode)[0]; // get the code only
                $inviteCode = trim($inviteCode);

                return response()->json([
                    'reply' => "⏳ Sedang memproses untuk masuk ke grup...",
                    'action' => 'join_group',
                    'invite_code' => $inviteCode
                ]);
            }

            if ($command === 'setgroup') {
                $remoteJid = $request->input('remoteJid', '');
                if (!str_contains($remoteJid, '@g.us')) {
                    return response()->json(['reply' => "⚠️ Perintah iki kudu dikirim saka njero Grup WhatsApp!"]);
                }

                $this->settings->set('wa_bot:group_jid', $remoteJid);

                return response()->json([
                    'reply' => "✅ *GRUP UTAMA BOT SUKSES DISETEL!*\n\nNotifikasi Store lan Server bakal dikirimake menyang grup iki.",
                    'action' => 'set_group',
                    'group_jid' => $remoteJid
                ]);
            }

            if ($command === 'info') {
                $userCount = User::count();
                $serverCount = Server::count();
                $nodeCount = Node::count();

                $reply = "📊 ━━━ *SYSTEM STATISTICAL METRICS* ━━━ 📊\n\n" .
                         "👥 Total Pangguna (User): *{$userCount}*\n" .
                         "🎮 Total Server Aktif: *{$serverCount}*\n" .
                         "🖥️ Total Node Wings: *{$nodeCount}*\n\n" .
                         "⚡ *{$botName} PANEL INFRASTRUCTURE*";
                return response()->json(['reply' => $reply, 'simulateProgress' => true]);
            }

            if ($command === 'broadcast') {
                if (!$target) {
                    return response()->json(['reply' => "⚠️ Format salah. Contoh: `broadcast Halo kabeh ana promo!`"]);
                }

                // Get all valid user phones
                $phones = User::whereNotNull('phone')
                    ->where('phone', '!=', '')
                    ->pluck('phone')
                    ->map(function($p) {
                        $c = preg_replace('/[^0-9]/', '', $p);
                        if (str_starts_with($c, '0')) {
                            $c = '62' . substr($c, 1);
                        }
                        return $c;
                    })
                    ->unique()
                    ->values()
                    ->toArray();

                if (empty($phones)) {
                    return response()->json(['reply' => "❌ Tidak ada user yang memiliki nomor telepon valid."]);
                }

                return response()->json([
                    'reply' => "⏳ Sedang mengirim pesan broadcast ke " . count($phones) . " pengguna...",
                    'action' => 'broadcast',
                    'message_text' => $target,
                    'targets' => $phones
                ]);
            }

            if ($command === 'restartbot') {
                return response()->json([
                    'reply' => "🔄 Bot sedang direstart...",
                    'action' => 'restart_bot'
                ]);
            }
        }

        return response()->json(['reply' => "Perintah tidak dikenali. Ketik `help` untuk daftar perintah."]);
    }

    public function groupUpdate(Request $request): JsonResponse
    {
        $secret = env('WA_BOT_SECRET', 'pterodactyl_wa_secret');
        if ($request->input('secret') !== $secret) {
            return response()->json(['success' => false], 401);
        }

        if ($request->input('action') === 'joined') {
            $this->settings->set('wa_bot:group_jid', $request->input('group_jid', ''));
            $this->settings->set('wa_bot:group_name', $request->input('group_name', ''));
        } elseif ($request->input('action') === 'left') {
            $this->settings->forget('wa_bot:group_jid');
            $this->settings->forget('wa_bot:group_name');
        }

        return response()->json(['success' => true]);
    }
}
