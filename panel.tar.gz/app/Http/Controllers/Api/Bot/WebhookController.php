<?php

namespace Pterodactyl\Http\Controllers\Api\Bot;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\User;
use Pterodactyl\Models\Server;
use Pterodactyl\Repositories\Wings\DaemonPowerRepository;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Support\Str;

use Pterodactyl\Models\Node;
use Pterodactyl\Models\Database;
use Pterodactyl\Models\Backup;
use Pterodactyl\Models\StoreDiscount;
use Pterodactyl\Contracts\Repository\SettingsRepositoryInterface;
use Pterodactyl\Services\Databases\DeployServerDatabaseService;
use Pterodactyl\Services\Databases\DatabaseManagementService;
use Pterodactyl\Services\Backups\InitiateBackupService;
use Pterodactyl\Services\Backups\DeleteBackupService;
use Pterodactyl\Services\Servers\SuspensionService;
use Illuminate\Contracts\Encryption\Encrypter;

class WebhookController extends Controller
{
    public function __construct(
        private DaemonPowerRepository $powerRepository,
        private SettingsRepositoryInterface $settings,
        private DeployServerDatabaseService $deployDatabaseService,
        private DatabaseManagementService $databaseManagementService,
        private InitiateBackupService $initiateBackupService,
        private DeleteBackupService $deleteBackupService,
        private SuspensionService $suspensionService,
        private Encrypter $encrypter
    ) {
    }

    public function handle(Request $request): JsonResponse
    {
        // Simple security check
        $secret = env('WA_BOT_SECRET', 'pterodactyl_wa_secret');
        if ($request->input('secret') !== $secret) {
            return response()->json(['reply' => 'Unauthorized access.'], 401);
        }

        $rawMessage = trim($request->input('message'));
        $phone = $request->input('phone');
        if (!$phone || !$rawMessage) {
            return response()->json(['reply' => 'Invalid payload.'], 400);
        }

        // Handle Prefix Logic:
        // 1. If starts with '.', strip it (e.g. '.mysrv' -> 'mysrv')
        // 2. If starts with any other non-alphanumeric prefix (like '!', '/', '#', '$', etc.), ignore it! Only '.' prefix is allowed if prefix is used.
        // 3. If starts with letters/digits (no prefix), support it directly (e.g. 'mysrv' -> 'mysrv').
        $message = $rawMessage;
        if (str_starts_with($rawMessage, '.')) {
            $message = trim(substr($rawMessage, 1));
        } else if (preg_match('/^[^\w\s]/u', $rawMessage)) {
            // Started with a symbol other than '.' (e.g. !help, /menu, #servers) -> Reject/Ignore
            return response()->json(['success' => true]);
        }
        
        $parts = explode(' ', $message);
        $command = strtolower($parts[0]);
        $target = trim(substr($message, strlen($parts[0]))) ?: null;

        // Clean incoming phone (remove +, -, spaces, etc)
        $cleanPhone = preg_replace('/[^0-9]/', '', $phone);
        
        // Normalize international country codes (e.g. 628 -> 08, 08 -> 628, 812 -> 62812)
        $phoneVariants = [$cleanPhone];
        if (str_starts_with($cleanPhone, '62')) {
            $phoneVariants[] = '0' . substr($cleanPhone, 2);
            $phoneVariants[] = substr($cleanPhone, 2); // without 62 (e.g. 831...)
        } elseif (str_starts_with($cleanPhone, '0')) {
            $phoneVariants[] = '62' . substr($cleanPhone, 1);
            $phoneVariants[] = substr($cleanPhone, 1); // without 0 (e.g. 831...)
        } elseif (str_starts_with($cleanPhone, '8')) {
            $phoneVariants[] = '62' . $cleanPhone;
            $phoneVariants[] = '0' . $cleanPhone;
        }

        // Fetch users that might match
        $users = User::whereNotNull('phone')->get();
        $user = $users->first(function($u) use ($phoneVariants) {
            $dbPhone = preg_replace('/[^0-9]/', '', $u->phone);
            if (empty($dbPhone)) return false;

            // Generate variants for DB phone as well
            $dbVariants = [$dbPhone];
            if (str_starts_with($dbPhone, '62')) {
                $dbVariants[] = '0' . substr($dbPhone, 2);
                $dbVariants[] = substr($dbPhone, 2);
            } elseif (str_starts_with($dbPhone, '0')) {
                $dbVariants[] = '62' . substr($dbPhone, 1);
                $dbVariants[] = substr($dbPhone, 1);
            } elseif (str_starts_with($dbPhone, '8')) {
                $dbVariants[] = '62' . $dbPhone;
                $dbVariants[] = '0' . $dbPhone;
            }

            return !empty(array_intersect($phoneVariants, $dbVariants));
        });

        if (!$user) {
            return response()->json(['reply' => "❌ Nomor WhatsApp Anda ({$cleanPhone}) belum terdaftar di panel.\n\nSilakan login ke panel dan update kolom Phone Number di Account Overview menjadi nomor Anda ini."]);
        }

        $botName = strtoupper($this->settings->get('wa_bot:bot_name', config('app.name', 'ZZAMCODE BOT')));

        $ownerNumber = preg_replace('/[^0-9]/', '', $this->settings->get('wa_bot:owner_number', ''));
        $ownerVariants = [];
        if (!empty($ownerNumber)) {
            $ownerVariants[] = $ownerNumber;
            if (str_starts_with($ownerNumber, '62')) {
                $ownerVariants[] = '0' . substr($ownerNumber, 2);
                $ownerVariants[] = substr($ownerNumber, 2);
            } elseif (str_starts_with($ownerNumber, '0')) {
                $ownerVariants[] = '62' . substr($ownerNumber, 1);
                $ownerVariants[] = substr($ownerNumber, 1);
            } elseif (str_starts_with($ownerNumber, '8')) {
                $ownerVariants[] = '62' . $ownerNumber;
                $ownerVariants[] = '0' . $ownerNumber;
            }
        }
        $isOwner = !empty($ownerVariants) && !empty(array_intersect($phoneVariants, $ownerVariants));

        // Enforce Group-Only mode
        $remoteJid = $request->input('remoteJid', '');
        $groupJid = $this->settings->get('wa_bot:group_jid', '');
        $isGroupMessage = str_contains($remoteJid, '@g.us');
        
        // Hanya owner yang bisa private
        if (!$isGroupMessage && !$isOwner) {
            if (in_array($command, ['mysrv', 'servers', 'list', 'start', 'stop', 'restart', 'kill', 'help', 'menu', 'mydb', 'mybackup'])) {
                return response()->json(['reply' => "⚠️ Bot saat ini hanya melayani perintah di dalam Grup resmi.\nAnda tidak dapat menggunakannya di *Private Chat*."]);
            }
            return response()->json(['success' => true]); // Ignore silently
        }
        
        // Jika sudah gabung ke satu grup, abaikan grup lain
        if ($isGroupMessage && $groupJid !== '' && $remoteJid !== $groupJid) {
            return response()->json(['success' => true]);
        }

        if ($command === 'mysrv' || $command === 'servers' || $command === 'list') {
            if ($target && in_array(explode(' ', $target)[0], ['start', 'stop', 'restart', 'kill', 'reinstall'])) {
                $subArgs = explode(' ', $target);
                $subCommand = $subArgs[0];
                $serverId = $subArgs[1] ?? null;

                if (!$serverId) {
                    return response()->json(['reply' => "⚠️ Format salah. Contoh: `mysrv {$subCommand} 453` atau `.mysrv {$subCommand} 453`"]);
                }

                $server = Server::where('id', $serverId)
                                ->where('owner_id', $user->id)
                                ->first();

                if (!$server) {
                    return response()->json(['reply' => "❌ Server dengan ID `{$serverId}` tidak ditemukan atau bukan milik Anda."]);
                }

                try {
                    if (in_array($subCommand, ['start', 'stop', 'restart', 'kill'])) {
                        if ($server->isSuspended()) {
                            return response()->json(['reply' => "❌ Server *{$server->name}* sedang di-suspend.\nSilakan perpanjang masa aktif terlebih dahulu."]);
                        }
                        $this->powerRepository->setServer($server)->send($subCommand);
                        return response()->json([
                            'reply' => "⚡ *{$botName} POWER CONTROL* ⚡\n\n" .
                                       "✅ Perintah *{$subCommand}* kasil dikirim!\n" .
                                       "📌 Target Server: *{$server->name}*\n" .
                                       "🆔 ID Server: `{$server->id}`"
                        ]);
                    } elseif ($subCommand === 'reinstall') {
                        if ($server->isSuspended()) {
                            return response()->json(['reply' => "❌ Server *{$server->name}* sedang di-suspend.\nSilakan perpanjang masa aktif terlebih dahulu."]);
                        }
                        app(\Pterodactyl\Repositories\Eloquent\ServerRepository::class)->update($server->id, ['status' => Server::STATUS_INSTALLING]);
                        return response()->json([
                            'reply' => "🛠️ *REINSTALL SERVER PROCESS* 🛠️\n\n" .
                                       "✅ Proses reinstall kanggo server *{$server->name}* wis diwiwiti.\n" .
                                       "⏳ Server ora bisa diakses sawetara wektu nganti proses rampung."
                        ]);
                    }
                } catch (\Exception $e) {
                    return response()->json(['reply' => "❌ Gagal ngirim perintah menyang server. Error: " . $e->getMessage()]);
                }
            }

            $servers = Server::with('node')->where('owner_id', $user->id)->get();
            if ($servers->isEmpty()) {
                return response()->json([
                    'reply' => "━━━━━━━━━━━━━━━━━━━━━━\n" .
                               "🎮 *SERVER MANAGEMENT* 🎮\n" .
                               "━━━━━━━━━━━━━━━━━━━━━━\n\n" .
                               "Sampeyan durung nduweni server ing panel."
                ]);
            }

            $reply = "╭━━━⚙️ *SERVER MANAGEMENT* ⚙️━━━╮\n" .
                     "┃ 1. 🟢 Start    : `mysrv start [id]`\n" .
                     "┃ 2. 🔄 Restart  : `mysrv restart [id]`\n" .
                     "┃ 3. 🔴 Stop     : `mysrv stop [id]`\n" .
                     "┃ 4. ☠️ Kill     : `mysrv kill [id]`\n" .
                     "┃ 5. 🛠️ Reinstall: `mysrv reinstall [id]`\n" .
                     "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n" .
                     "💡 *Info:* Perintah bisa tanpa prefix utawa nggunakake prefix `.` (tuladha: `mysrv` / `.mysrv`)\n\n" .
                     "📋 *DAFTAR SERVER SAMPEYAN:*\n" .
                     "─────────────────────────\n";

            foreach ($servers as $idx => $srv) {
                $expired = "♾️ Permanen";
                if (isset($srv->store_expires_at) && $srv->store_expires_at) {
                    $expiryDate = \Carbon\Carbon::parse($srv->store_expires_at);
                    $now = \Carbon\Carbon::now();
                    if ($expiryDate->isPast()) {
                        $expired = $expiryDate->translatedFormat('d F Y') . " (❌ EXPIRED)";
                    } else {
                        $sisaHari = (int) $now->diffInDays($expiryDate, false);
                        $expired = $expiryDate->translatedFormat('d F Y') . " ({$sisaHari} hari)";
                    }
                }
                
                $status = "🟢 Aktif";
                if ($srv->isSuspended()) $status = "🔴 Suspended";
                elseif (!$srv->isInstalled()) $status = "🟡 Installing";

                $dbCount = $srv->databases()->count();
                $backupCount = $srv->backups()->count();

                $reply .= "📌 *ID Server*: `{$srv->id}`\n" .
                          "📛 *Nama*: *{$srv->name}*\n" .
                          "⏳ *Expired*: {$expired}\n" .
                          "📊 *Status*: {$status}\n" .
                          "🗄️ *Database*: {$dbCount} | 💾 *Backup*: {$backupCount}\n" .
                          "─────────────────────────\n";
            }
            $reply .= "✨ *Total*: `{$servers->count()}` server kasedhiya.";
            return response()->json(['reply' => $reply, 'simulateProgress' => true, 'botName' => $botName]);
        }

        if ($command === 'help' || $command === 'menu') {
            $reply = "╭━━━🤖 *{$botName} ASSISTANT* 🤖━━━╮\n" .
                     "┃ Sugeng rawuh ing WhatsApp Bot Panel!\n" .
                     "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n" .
                     "🎮 *SERVER MANAGEMENT:*\n" .
                     "• `mysrv` — Daftar server & kontrol power\n" .
                     "• `mysrv start/stop/restart/kill [id]`\n" .
                     "• `mysrv reinstall [id]`\n\n" .
                     "🗄️ *DATABASE MANAGEMENT:*\n" .
                     "• `mydb` — Menu database management\n" .
                     "• `mydb createdb [server_id] [nama_db]`\n" .
                     "• `mydb listdb [server_id]`\n" .
                     "• `mydb deldb [server_id] [db_id]`\n\n" .
                     "💾 *BACKUP MANAGEMENT:*\n" .
                     "• `mybackup` — Menu backup management\n" .
                     "• `mybackup create [server_id]`\n" .
                     "• `mybackup list [server_id]`\n" .
                     "• `mybackup delete [server_id] [backup_id]`\n\n" .
                     "✨ *Fitur Bot:* Tanpa prefix utawa nganggo prefix `.`\n" .
                     "⚡ *Powered by {$botName} System*";
            return response()->json(['reply' => $reply, 'simulateProgress' => true, 'botName' => $botName]);
        }

        // =====================================
        // MYDB — DATABASE MANAGEMENT
        // =====================================

        if ($command === 'mydb') {
            $subArgs = $target ? explode(' ', $target) : [];
            $subCommand = strtolower($subArgs[0] ?? '');
            $serverId = $subArgs[1] ?? null;

            // Show mydb menu if no subcommand
            if (!$subCommand) {
                $servers = Server::where('owner_id', $user->id)->get();
                $reply = "╭━━━🗄️ *DATABASE MANAGEMENT* 🗄️━━━╮\n" .
                         "┃ 1. ➕ Create : `mydb createdb [server_id] [nama_db]`\n" .
                         "┃ 2. 📋 List   : `mydb listdb [server_id]`\n" .
                         "┃ 3. 🗑️ Delete : `mydb deldb [server_id] [db_id]`\n" .
                         "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n";

                if ($servers->isEmpty()) {
                    $reply .= "Sampeyan durung nduweni server ing panel.";
                } else {
                    $reply .= "📋 *SERVER SAMPEYAN:*\n" .
                              "─────────────────────────\n";
                    foreach ($servers as $srv) {
                        $dbCount = $srv->databases()->count();
                        $dbLimit = $srv->database_limit ?? '∞';
                        $reply .= "• `{$srv->id}` — *{$srv->name}* ({$dbCount}/{$dbLimit} DB)\n";
                    }
                }
                $reply .= "\n💡 Credential dikirim ke *Private Chat*";
                return response()->json(['reply' => $reply, 'simulateProgress' => true, 'botName' => $botName]);
            }

            // Subcommands that need server_id
            if (in_array($subCommand, ['createdb', 'buatdb', 'listdb', 'deldb', 'deletedb', 'hapusdb'])) {
                if (!$serverId) {
                    return response()->json(['reply' => "⚠️ Format salah.\n\nContoh: `mydb {$subCommand} [server_id]`"]);
                }

                $server = Server::where('id', $serverId)->where('owner_id', $user->id)->first();
                if (!$server) {
                    return response()->json(['reply' => "❌ Server dengan ID `{$serverId}` tidak ditemukan atau bukan milik Anda."]);
                }

                // ── CREATE DATABASE ──
                if ($subCommand === 'createdb' || $subCommand === 'buatdb') {
                    if ($server->isSuspended()) {
                        return response()->json(['reply' => "❌ Server *{$server->name}* sedang di-suspend. Tidak bisa membuat database."]);
                    }
                    try {
                        $dbLabel = $subArgs[2] ?? 'wabot';

                        $database = $this->deployDatabaseService->handle($server, [
                            'database' => $dbLabel,
                            'remote' => 'localhost',
                        ]);

                        $dbHost = $database->host;
                        $decryptedPassword = $this->encrypter->decrypt($database->password);

                        $privateMsg = "🔒 ━━━ *DATABASE CREDENTIALS* ━━━ 🔒\n\n" .
                                      "📌 *Server*: {$server->name} (ID: {$server->id})\n\n" .
                                      "🗄️ *Host*: {$dbHost->host}\n" .
                                      "🔌 *Port*: {$dbHost->port}\n" .
                                      "📛 *Database*: {$database->database}\n" .
                                      "👤 *Username*: {$database->username}\n" .
                                      "🔑 *Password*: `{$decryptedPassword}`\n\n" .
                                      "⚠️ *Simpan data iki! Password ora bisa ditampilake maneh.*\n\n" .
                                      "⚡ *{$botName} DATABASE SYSTEM*";

                        return response()->json([
                            'reply' => "✅ *DATABASE BERHASIL DIBUAT!*\n\n" .
                                       "📌 Server: *{$server->name}*\n" .
                                       "🗄️ Database: `{$database->database}`\n" .
                                       "🌐 Connections From: `localhost`\n\n" .
                                       "📩 Credential dikirim ke *Private Chat* sampeyan.",
                            'simulateProgress' => true,
                            'botName' => $botName,
                            'private_reply' => $privateMsg,
                            'target_phone' => $cleanPhone
                        ]);
                    } catch (\Pterodactyl\Exceptions\Service\Database\TooManyDatabasesException $e) {
                        return response()->json(['reply' => "❌ Server wis tekan limit database maksimal."]);
                    } catch (\Pterodactyl\Exceptions\Service\Database\NoSuitableDatabaseHostException $e) {
                        return response()->json(['reply' => "❌ Ora ana database host sing kasedhiya kanggo server iki."]);
                    } catch (\Exception $e) {
                        return response()->json(['reply' => "❌ Gagal gawe database: " . $e->getMessage()]);
                    }
                }

                // ── LIST DATABASES ──
                if ($subCommand === 'listdb') {
                    $databases = Database::with('host')->where('server_id', $server->id)->get();
                    if ($databases->isEmpty()) {
                        return response()->json(['reply' => "📋 Server *{$server->name}* durung nduweni database."]);
                    }

                    $reply = "╭━━━🗄️ *DATABASE LIST* 🗄️━━━╮\n" .
                             "┃ Server: *{$server->name}* (ID: {$server->id})\n" .
                             "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n";

                    $count = 1;
                    foreach ($databases as $db) {
                        $host = $db->host;
                        $reply .= "{$count}. 🗄️ *{$db->database}*\n" .
                                  "   🆔 DB ID: `{$db->id}`\n" .
                                  "   🌐 Host: `{$host->host}:{$host->port}`\n" .
                                  "   👤 User: `{$db->username}`\n\n";
                        $count++;
                    }
                    $reply .= "🗑️ Hapus: `mydb deldb {$server->id} [db_id]`";
                    return response()->json(['reply' => $reply, 'simulateProgress' => true, 'botName' => $botName]);
                }

                // ── DELETE DATABASE ──
                if ($subCommand === 'deldb' || $subCommand === 'deletedb' || $subCommand === 'hapusdb') {
                    $dbId = $subArgs[2] ?? null;
                    if (!$dbId) {
                        return response()->json(['reply' => "⚠️ Format salah.\n\nContoh: `mydb deldb {$server->id} 12`\n\nGunakan `mydb listdb {$server->id}` untuk melihat daftar DB."]);
                    }

                    $database = Database::where('id', $dbId)->where('server_id', $server->id)->first();
                    if (!$database) {
                        return response()->json(['reply' => "❌ Database dengan ID `{$dbId}` tidak ditemukan di server ini."]);
                    }

                    try {
                        $dbName = $database->database;
                        $this->databaseManagementService->delete($database);
                        return response()->json([
                            'reply' => "✅ *DATABASE BERHASIL DIHAPUS!*\n\n" .
                                       "📌 Server: *{$server->name}*\n" .
                                       "🗄️ Database: `{$dbName}`\n\n" .
                                       "⚡ *{$botName} DATABASE SYSTEM*"
                        ]);
                    } catch (\Exception $e) {
                        return response()->json(['reply' => "❌ Gagal hapus database: " . $e->getMessage()]);
                    }
                }
            }

            return response()->json(['reply' => "⚠️ Subcommand tidak dikenali.\n\nKetik `mydb` untuk melihat daftar perintah database."]);
        }

        // =====================================
        // MYBACKUP — BACKUP MANAGEMENT
        // =====================================

        if ($command === 'mybackup') {
            $subArgs = $target ? explode(' ', $target) : [];
            $subCommand = strtolower($subArgs[0] ?? '');
            $serverId = $subArgs[1] ?? null;

            // Show mybackup menu if no subcommand
            if (!$subCommand) {
                $servers = Server::where('owner_id', $user->id)->get();
                $reply = "╭━━━💾 *BACKUP MANAGEMENT* 💾━━━╮\n" .
                         "┃ 1. ➕ Create : `mybackup create [server_id]`\n" .
                         "┃ 2. 📋 List   : `mybackup list [server_id]`\n" .
                         "┃ 3. 🗑️ Delete : `mybackup delete [server_id] [backup_id]`\n" .
                         "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n";

                if ($servers->isEmpty()) {
                    $reply .= "Sampeyan durung nduweni server ing panel.";
                } else {
                    $reply .= "📋 *SERVER SAMPEYAN:*\n" .
                              "─────────────────────────\n";
                    foreach ($servers as $srv) {
                        $bkCount = $srv->backups()->count();
                        $bkLimit = $srv->backup_limit ?? '∞';
                        $reply .= "• `{$srv->id}` — *{$srv->name}* ({$bkCount}/{$bkLimit} Backup)\n";
                    }
                }
                $reply .= "\n💡 Detail backup dikirim ke *Private Chat*";
                return response()->json(['reply' => $reply, 'simulateProgress' => true, 'botName' => $botName]);
            }

            // Subcommands that need server_id
            if (in_array($subCommand, ['create', 'list', 'delete', 'hapus'])) {
                if (!$serverId) {
                    return response()->json(['reply' => "⚠️ Format salah.\n\nContoh: `mybackup {$subCommand} [server_id]`"]);
                }

                $server = Server::where('id', $serverId)->where('owner_id', $user->id)->first();
                if (!$server) {
                    return response()->json(['reply' => "❌ Server dengan ID `{$serverId}` tidak ditemukan atau bukan milik Anda."]);
                }

                // ── CREATE BACKUP ──
                if ($subCommand === 'create') {
                    if ($server->isSuspended()) {
                        return response()->json(['reply' => "❌ Server *{$server->name}* sedang di-suspend. Tidak bisa membuat backup."]);
                    }
                    try {
                        $backupName = isset($subArgs[2]) ? implode(' ', array_slice($subArgs, 2)) : null;
                        $backup = $this->initiateBackupService->handle($server, $backupName, true);

                        $privateMsg = "🔒 ━━━ *BACKUP DETAILS* ━━━ 🔒\n\n" .
                                      "📌 *Server*: {$server->name} (ID: {$server->id})\n" .
                                      "🆔 *Backup ID*: `{$backup->id}`\n" .
                                      "📛 *Name*: {$backup->name}\n" .
                                      "🔑 *UUID*: `{$backup->uuid}`\n" .
                                      "📅 *Created*: {$backup->created_at}\n\n" .
                                      "⏳ Backup sedang diproses oleh Wings daemon.\n" .
                                      "Cek status di panel.\n\n" .
                                      "⚡ *{$botName} BACKUP SYSTEM*";

                        return response()->json([
                            'reply' => "✅ *BACKUP BERHASIL DIBUAT!*\n\n" .
                                       "📌 Server: *{$server->name}*\n" .
                                       "📛 Backup: *{$backup->name}*\n\n" .
                                       "📩 Detail dikirim ke *Private Chat* sampeyan.",
                            'simulateProgress' => true,
                            'botName' => $botName,
                            'private_reply' => $privateMsg,
                            'target_phone' => $cleanPhone
                        ]);
                    } catch (\Pterodactyl\Exceptions\Service\Backup\TooManyBackupsException $e) {
                        return response()->json(['reply' => "❌ Server wis tekan limit backup maksimal.\n\nHapus backup lawas: `mybackup delete {$server->id} [backup_id]`"]);
                    } catch (\Exception $e) {
                        return response()->json(['reply' => "❌ Gagal gawe backup: " . $e->getMessage()]);
                    }
                }

                // ── LIST BACKUPS ──
                if ($subCommand === 'list') {
                    $backups = Backup::where('server_id', $server->id)
                        ->orderBy('created_at', 'desc')
                        ->get();

                    if ($backups->isEmpty()) {
                        return response()->json(['reply' => "📋 Server *{$server->name}* durung nduweni backup."]);
                    }

                    $reply = "╭━━━💾 *BACKUP LIST* 💾━━━╮\n" .
                             "┃ Server: *{$server->name}* (ID: {$server->id})\n" .
                             "╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\n\n";

                    $count = 1;
                    foreach ($backups as $bk) {
                        $statusIcon = $bk->is_successful ? "✅" : ($bk->completed_at ? "❌" : "⏳");
                        $size = $bk->bytes > 0 ? round($bk->bytes / 1024 / 1024, 2) . ' MB' : '-';
                        $date = \Carbon\Carbon::parse($bk->created_at)->translatedFormat('d M Y H:i');
                        $lockIcon = $bk->is_locked ? " 🔒" : "";

                        $reply .= "{$count}. {$statusIcon} *{$bk->name}*{$lockIcon}\n" .
                                  "   🆔 ID: `{$bk->id}` | 📦 {$size}\n" .
                                  "   📅 {$date}\n\n";
                        $count++;
                    }
                    $reply .= "🗑️ Hapus: `mybackup delete {$server->id} [backup_id]`";
                    return response()->json(['reply' => $reply, 'simulateProgress' => true, 'botName' => $botName]);
                }

                // ── DELETE BACKUP ──
                if ($subCommand === 'delete' || $subCommand === 'hapus') {
                    $backupId = $subArgs[2] ?? null;
                    if (!$backupId) {
                        return response()->json(['reply' => "⚠️ Format salah.\n\nContoh: `mybackup delete {$server->id} 12`\n\nGunakan `mybackup list {$server->id}` untuk melihat daftar backup."]);
                    }

                    $backup = Backup::where('id', $backupId)->where('server_id', $server->id)->first();
                    if (!$backup) {
                        return response()->json(['reply' => "❌ Backup dengan ID `{$backupId}` tidak ditemukan di server ini."]);
                    }

                    if ($backup->is_locked) {
                        return response()->json(['reply' => "🔒 Backup *{$backup->name}* di-lock dan tidak bisa dihapus.\nUnlock dulu lewat panel."]);
                    }

                    try {
                        $bkName = $backup->name;
                        $this->deleteBackupService->handle($backup);
                        return response()->json([
                            'reply' => "✅ *BACKUP BERHASIL DIHAPUS!*\n\n" .
                                       "📌 Server: *{$server->name}*\n" .
                                       "💾 Backup: `{$bkName}`\n\n" .
                                       "⚡ *{$botName} BACKUP SYSTEM*"
                        ]);
                    } catch (\Exception $e) {
                        return response()->json(['reply' => "❌ Gagal hapus backup: " . $e->getMessage()]);
                    }
                }
            }

            return response()->json(['reply' => "⚠️ Subcommand tidak dikenali.\n\nKetik `mybackup` untuk melihat daftar perintah backup."]);
        }

        // =====================================
        // BOT OWNER COMMANDS
        // =====================================

        if (in_array($command, ['menuowner', 'creatediscount', 'join', 'setgroup', 'info', 'broadcast', 'restartbot'])) {
            if (!$isOwner) {
                return response()->json(['reply' => "❌ Anda tidak memiliki izin untuk menggunakan perintah ini."]);
            }

            if ($command === 'menuowner') {
                $reply = "👑 ━━━ *EXECUTIVE OWNER CONTROL* ━━━ 👑\n\n" .
                         "⚙️ *PERINTAH OWNER PANEL:*\n" .
                         "• `creatediscount <code> <percent> <max_uses>`\n" .
                         "  └> *Gawe kode diskon store anyar*\n" .
                         "• `join <link_grup>`\n" .
                         "  └> *Gabung bot menyang grup WA*\n" .
                         "• `setgroup`\n" .
                         "  └> *Setel grup utama kanggo notifikasi bot*\n" .
                         "• `info`\n" .
                         "  └> *Tampilake statistik sistem panel*\n" .
                         "• `broadcast <pesan>`\n" .
                         "  └> *Kirim pesan massal menyang kabeh user*\n" .
                         "• `restartbot`\n" .
                         "  └> *Restart proses daemon PM2 bot*\n\n" .
                         "⚡ *{$botName} ADMIN CONSOLE*";
                return response()->json(['reply' => $reply, 'simulateProgress' => true, 'botName' => $botName]);
            }

            if ($command === 'creatediscount') {
                $args = explode(' ', $target);
                if (count($args) < 3) {
                    return response()->json([
                        'reply' => "⚠️ *Format Salah!*\n\nContoh: `creatediscount DISKON50 50 100`"
                    ]);
                }
                
                $code = strtoupper($args[0]);
                $percent = (int)$args[1];
                $maxUses = (int)$args[2];

                StoreDiscount::create([
                    'code' => $code,
                    'discount_percent' => $percent,
                    'max_uses' => $maxUses,
                    'uses' => 0
                ]);

                // Broadcast to group
                $broadcastMsg = "🎉 *PROMO KODE DISKON STORE!* 🎉\n\n" .
                                "Oleh diskon *{$percent}%* kanggo tuku server ing Store Panel!\n\n" .
                                "👉 Kode Voucher: *{$code}*\n" .
                                "⏳ Kuota Pemakaian: *{$maxUses}x*\n\n" .
                                "🔥 Ayo langsung dingo sadurunge entek!";
                app(\Pterodactyl\Services\WhatsApp\WhatsAppNotifierService::class)->sendToGroup($broadcastMsg);

                return response()->json([
                    'reply' => "✅ *KODE DISKON SUKSES DIBUAT!*\n\n" .
                               "📌 Kode: *{$code}*\n" .
                               "🏷️ Diskon: *{$percent}%*\n" .
                               "👥 Maksimal Kuota: *{$maxUses}x*"
                ]);
            }

            if ($command === 'join') {
                if (!$target || !str_contains($target, 'chat.whatsapp.com/')) {
                    return response()->json(['reply' => "⚠️ Format salah. Kirimkan link invite WhatsApp grup."]);
                }

                $currentGroup = $this->settings->get('wa_bot:group_jid', '');
                if ($currentGroup !== '') {
                    return response()->json(['reply' => "❌ Bot wis ana ing njero grup liya.\nBot mung bisa join 1 grup. Keluarkan bot saka grup saiki dhisik."]);
                }

                $inviteCode = explode('chat.whatsapp.com/', $target)[1];
                $inviteCode = explode(' ', $inviteCode)[0]; // get the code only
                $inviteCode = trim($inviteCode);

                return response()->json([
                    'reply' => "⏳ Sedang memproses untuk masuk ke grup...",
                    'action' => 'join_group',
                    'invite_code' => $inviteCode
                ]);
            }

            if ($command === 'setgroup') {
                $remoteJid = $request->input('remoteJid', '');
                if (!str_contains($remoteJid, '@g.us')) {
                    return response()->json(['reply' => "⚠️ Perintah iki kudu dikirim saka njero Grup WhatsApp!"]);
                }

                $this->settings->set('wa_bot:group_jid', $remoteJid);

                return response()->json([
                    'reply' => "✅ *GRUP UTAMA BOT SUKSES DISETEL!*\n\nNotifikasi Store lan Server bakal dikirimake menyang grup iki.",
                    'action' => 'set_group',
                    'group_jid' => $remoteJid
                ]);
            }

            if ($command === 'info') {
                $userCount = User::count();
                $serverCount = Server::count();
                $nodeCount = Node::count();

                $reply = "📊 ━━━ *SYSTEM STATISTICAL METRICS* ━━━ 📊\n\n" .
                         "👥 Total Pangguna (User): *{$userCount}*\n" .
                         "🎮 Total Server Aktif: *{$serverCount}*\n" .
                         "🖥️ Total Node Wings: *{$nodeCount}*\n\n" .
                         "⚡ *{$botName} PANEL INFRASTRUCTURE*";
                return response()->json(['reply' => $reply, 'simulateProgress' => true, 'botName' => $botName]);
            }

            if ($command === 'broadcast') {
                if (!$target) {
                    return response()->json(['reply' => "⚠️ Format salah. Contoh: `broadcast Halo kabeh ana promo!`"]);
                }

                // Get all valid user phones
                $phones = User::whereNotNull('phone')
                    ->where('phone', '!=', '')
                    ->pluck('phone')
                    ->map(function($p) {
                        $c = preg_replace('/[^0-9]/', '', $p);
                        if (str_starts_with($c, '0')) {
                            $c = '62' . substr($c, 1);
                        }
                        return $c;
                    })
                    ->unique()
                    ->values()
                    ->toArray();

                if (empty($phones)) {
                    return response()->json(['reply' => "❌ Tidak ada user yang memiliki nomor telepon valid."]);
                }

                return response()->json([
                    'reply' => "⏳ Sedang mengirim pesan broadcast ke " . count($phones) . " pengguna...",
                    'action' => 'broadcast',
                    'message_text' => $target,
                    'targets' => $phones
                ]);
            }

            if ($command === 'restartbot') {
                return response()->json([
                    'reply' => "🔄 Bot sedang direstart...",
                    'action' => 'restart_bot'
                ]);
            }
        }

        return response()->json(['reply' => "Perintah tidak dikenali. Ketik `help` untuk daftar perintah."]);
    }

    public function groupUpdate(Request $request): JsonResponse
    {
        $secret = env('WA_BOT_SECRET', 'pterodactyl_wa_secret');
        if ($request->input('secret') !== $secret) {
            return response()->json(['success' => false], 401);
        }

        if ($request->input('action') === 'joined') {
            $this->settings->set('wa_bot:group_jid', $request->input('group_jid', ''));
            $this->settings->set('wa_bot:group_name', $request->input('group_name', ''));
        } elseif ($request->input('action') === 'left') {
            $this->settings->forget('wa_bot:group_jid');
            $this->settings->forget('wa_bot:group_name');
        }

        return response()->json(['success' => true]);
    }
}
