<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Account;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Models\User;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;

class UpdateAvatarController extends ClientApiController
{
    /**
     * Update the user's avatar profile picture.
     */
    public function update(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        $avatarPath = null;

        if ($request->hasFile('avatar')) {
            $request->validate([
                'avatar' => 'required|image|mimes:jpeg,png,jpg,gif,webp|max:5120',
            ]);

            $file = $request->file('avatar');
            $filename = 'user_' . $user->uuid . '_' . time() . '.' . $file->getClientOriginalExtension();
            
            $publicPath = public_path('avatars');
            if (!file_exists($publicPath)) {
                mkdir($publicPath, 0755, true);
            }

            $file->move($publicPath, $filename);
            $avatarPath = '/avatars/' . $filename;
        } elseif ($request->has('avatar_base64')) {
            $base64Image = $request->input('avatar_base64');
            if (preg_match('/^data:image\/(\w+);base64,/', $base64Image, $type)) {
                $data = substr($base64Image, strpos($base64Image, ',') + 1);
                $ext = strtolower($type[1]);

                if (!in_array($ext, ['jpg', 'jpeg', 'gif', 'png', 'webp'])) {
                    return response()->json(['error' => 'Format gambar tidak valid.'], 422);
                }

                $data = base64_decode($data);
                if ($data === false) {
                    return response()->json(['error' => 'Gagal memproses gambar.'], 422);
                }

                $filename = 'user_' . $user->uuid . '_' . time() . '.' . $ext;
                $publicPath = public_path('avatars');
                if (!file_exists($publicPath)) {
                    mkdir($publicPath, 0755, true);
                }

                file_put_contents($publicPath . '/' . $filename, $data);
                $avatarPath = '/avatars/' . $filename;
            }
        }

        if (!$avatarPath) {
            return response()->json(['error' => 'Harap unggah gambar avatar yang valid.'], 422);
        }

        // Hapus avatar lama jika ada
        if ($user->avatar_url && str_contains($user->avatar_url, '/avatars/')) {
            $oldPath = public_path(ltrim($user->avatar_url, '/'));
            if (file_exists($oldPath)) {
                @unlink($oldPath);
            }
        }

        $user->forceFill([
            'avatar_url' => $avatarPath,
        ])->save();

        return response()->json([
            'success' => true,
            'avatar_url' => $avatarPath,
        ]);
    }

    /**
     * Remove user avatar.
     */
    public function destroy(Request $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();

        if ($user->avatar_url && str_contains($user->avatar_url, '/avatars/')) {
            $oldPath = public_path(ltrim($user->avatar_url, '/'));
            if (file_exists($oldPath)) {
                @unlink($oldPath);
            }
        }

        $user->forceFill([
            'avatar_url' => null,
        ])->save();

        return response()->json([
            'success' => true,
            'avatar_url' => null,
        ]);
    }
}