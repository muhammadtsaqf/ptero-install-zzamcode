<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Server;
use Pterodactyl\Models\ServerDomain;
use Illuminate\Http\JsonResponse;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Transformers\Api\Client\ServerDomainTransformer;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\GetDomainsRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\StoreDomainRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\DeleteDomainRequest;

class DomainController extends ClientApiController
{
    /**
     * Return all domains mapped to a server along with node host info for DNS target.
     */
    public function index(GetDomainsRequest $request, Server $server): array
    {
        $server->loadMissing('node');

        $domains = $this->fractal->collection($server->domains)
            ->transformWith($this->getTransformer(ServerDomainTransformer::class))
            ->toArray();

        // Include node IP and FQDN info so frontend can display DNS instruction to user
        return array_merge($domains, [
            'meta' => [
                'node_ip' => $server->node->ip,
                'node_fqdn' => $server->node->fqdn,
            ],
        ]);
    }

    /**
     * Add a custom domain mapping to a server.
     */
    public function store(StoreDomainRequest $request, Server $server): array
    {
        // Limit max custom domains per server if necessary (e.g. max 10)
        if ($server->domains()->count() >= 10) {
            throw new DisplayException('You have reached the maximum allowed domain mappings (10) for this server.');
        }

        $domainName = strtolower(trim($request->input('domain')));

        $domain = $server->domains()->create([
            'domain' => $domainName,
            'target_port' => $request->input('target_port'),
        ]);

        Activity::event('server:domain.create')
            ->subject($domain)
            ->property(['domain' => $domain->domain, 'target_port' => $domain->target_port])
            ->log();

        return $this->fractal->item($domain)
            ->transformWith($this->getTransformer(ServerDomainTransformer::class))
            ->toArray();
    }

    /**
     * Remove a custom domain mapping from a server.
     */
    public function delete(DeleteDomainRequest $request, Server $server, ServerDomain $domain): JsonResponse
    {
        if ($domain->server_id !== $server->id) {
            throw new DisplayException('This domain mapping does not belong to the current server.');
        }

        $domain->delete();

        Activity::event('server:domain.delete')
            ->property(['domain' => $domain->domain])
            ->log();

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }
}
