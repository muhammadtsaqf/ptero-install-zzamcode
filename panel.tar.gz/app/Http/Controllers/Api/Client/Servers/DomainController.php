<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Server;
use Pterodactyl\Models\ServerDomain;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Transformers\Api\Client\ServerDomainTransformer;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\GetDomainsRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\StoreDomainRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\DeleteDomainRequest;

class DomainController extends ClientApiController
{
    /**
     * Return all domains mapped to a server along with node host info for DNS target.
     */
    public function index(GetDomainsRequest $request, Server $server): array
    {
        $server->loadMissing(['node', 'domains']);

        // Generate CNAME code for old records if missing
        foreach ($server->domains as $d) {
            if (empty($d->cname_code)) {
                try {
                    $d->update(['cname_code' => 'srv-' . Str::lower(Str::random(6))]);
                } catch (\Throwable $e) {
                    // Ignore error if column not yet migrated in old DB schema
                }
            }
        }

        $domains = $this->fractal->collection($server->domains)
            ->transformWith($this->getTransformer(ServerDomainTransformer::class))
            ->toArray();

        return array_merge($domains, [
            'meta' => [
                'node_ip' => $server->node->ip,
                'node_fqdn' => $server->node->fqdn,
            ],
        ]);
    }

    /**
     * Add a custom domain mapping to a server.
     */
    public function store(StoreDomainRequest $request, Server $server): array
    {
        if ($server->domains()->count() >= 10) {
            throw new DisplayException('You have reached the maximum allowed domain mappings (10) for this server.');
        }

        $domainName = strtolower(trim($request->input('domain')));
        $cnameCode = 'srv-' . Str::lower(Str::random(6));

        try {
            $domain = $server->domains()->create([
                'domain' => $domainName,
                'cname_code' => $cnameCode,
                'target_port' => $request->input('target_port'),
            ]);
        } catch (\Throwable $e) {
            // Fallback for servers where cname_code column might be missing if migration wasn't run
            try {
                $domain = $server->domains()->create([
                    'domain' => $domainName,
                    'target_port' => $request->input('target_port'),
                ]);
            } catch (\Throwable $ex) {
                throw new DisplayException('Failed to add custom domain. Please run "php artisan migrate" on the server panel: ' . $ex->getMessage());
            }
        }

        try {
            Activity::event('server:domain.create')
                ->subject($server)
                ->property(['domain' => $domain->domain, 'cname_code' => $cnameCode, 'target_port' => $domain->target_port])
                ->log();
        } catch (\Throwable $e) {
            // Log activity error shouldn't block domain creation
        }

        return $this->fractal->item($domain)
            ->transformWith($this->getTransformer(ServerDomainTransformer::class))
            ->toArray();
    }

    /**
     * Check/Verify connection status of custom domain DNS.
     */
    public function verify(GetDomainsRequest $request, Server $server, ServerDomain $domain): JsonResponse
    {
        if ($domain->server_id !== $server->id) {
            throw new DisplayException('This domain mapping does not belong to the current server.');
        }

        $server->loadMissing('node');
        $nodeFqdn = strtolower($server->node->fqdn);
        $nodeIp = $server->node->ip;
        $cnameTarget = strtolower($domain->cname_code ? "{$domain->cname_code}.{$nodeFqdn}" : $nodeFqdn);

        $isResolved = false;
        $details = 'DNS record not found yet or pending propagation.';

        // Check CNAME records via PHP dns_get_record
        $dnsRecords = @dns_get_record($domain->domain, DNS_CNAME);
        if ($dnsRecords && is_array($dnsRecords)) {
            foreach ($dnsRecords as $rec) {
                $target = strtolower(rtrim($rec['target'] ?? '', '.'));
                if ($target === rtrim($cnameTarget, '.') || $target === rtrim($nodeFqdn, '.')) {
                    $isResolved = true;
                    $details = "Connected! Domain points correctly to {$target}";
                    break;
                }
            }
        }

        // Fallback: Check IP resolution if CNAME record is proxied (e.g. Cloudflare proxy)
        if (!$isResolved) {
            $resolvedIp = @gethostbyname($domain->domain);
            if ($resolvedIp && $resolvedIp !== $domain->domain) {
                if ($resolvedIp === $nodeIp) {
                    $isResolved = true;
                    $details = "Connected! Domain resolves to server node IP ({$nodeIp}).";
                } else {
                    $isResolved = true;
                    $details = "Connected! Domain DNS is active (Resolves to {$resolvedIp}).";
                }
            }
        }

        return new JsonResponse([
            'connected' => $isResolved,
            'message' => $details,
            'cname_target' => $cnameTarget,
        ]);
    }

    /**
     * Remove a custom domain mapping from a server.
     */
    public function delete(DeleteDomainRequest $request, Server $server, ServerDomain $domain): JsonResponse
    {
        if ($domain->server_id !== $server->id) {
            throw new DisplayException('This domain mapping does not belong to the current server.');
        }

        $domainName = $domain->domain;
        $domain->delete();

        try {
            Activity::event('server:domain.delete')
                ->subject($server)
                ->property(['domain' => $domainName])
                ->log();
        } catch (\Throwable $e) {
            // Ignore activity logging errors
        }

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }
}
