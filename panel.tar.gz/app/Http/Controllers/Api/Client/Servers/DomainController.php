<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Pterodactyl\Models\Server;
use Pterodactyl\Models\ServerDomain;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Str;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Exceptions\DisplayException;
use Pterodactyl\Transformers\Api\Client\ServerDomainTransformer;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\GetDomainsRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\StoreDomainRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domains\DeleteDomainRequest;

class DomainController extends ClientApiController
{
    /**
     * Return all domains mapped to a server along with node host info for DNS target.
     */
    public function index(GetDomainsRequest $request, Server $server): array
    {
        $server->loadMissing(['node', 'domains']);

        $cnameCode = 'srv-' . substr(md5('server_' . $server->id), 0, 6);

        // Pastikan CNAME code stabil per server (1 panel / 1 server = 1 CNAME target stabil)
        foreach ($server->domains as $d) {
            if (empty($d->cname_code) || $d->cname_code !== $cnameCode) {
                try {
                    $d->update(['cname_code' => $cnameCode]);
                } catch (\Throwable $e) {
                    // Ignore error if column not present yet
                }
            }
        }

        $domains = $this->fractal->collection($server->domains)
            ->transformWith($this->getTransformer(ServerDomainTransformer::class))
            ->toArray();

        return array_merge($domains, [
            'meta' => [
                'node_ip' => $server->node->ip,
                'node_fqdn' => $server->node->fqdn,
            ],
        ]);
    }

    /**
     * Add a custom domain mapping to a server.
     */
    public function store(StoreDomainRequest $request, Server $server): array
    {
        if ($server->domains()->count() >= 10) {
            throw new DisplayException('You have reached the maximum allowed domain mappings (10) for this server.');
        }

        $domainName = strtolower(trim($request->input('domain')));
        // Consistent CNAME code per server (1 panel / 1 server has a stable CNAME target)
        $cnameCode = 'srv-' . substr(md5('server_' . $server->id), 0, 6);

        try {
            $domain = $server->domains()->create([
                'domain' => $domainName,
                'cname_code' => $cnameCode,
                'target_port' => $request->input('target_port'),
            ]);
        } catch (\Throwable $e) {
            try {
                $domain = $server->domains()->create([
                    'domain' => $domainName,
                    'target_port' => $request->input('target_port'),
                ]);
            } catch (\Throwable $ex) {
                throw new DisplayException('Failed to add custom domain: ' . $ex->getMessage());
            }
        }

        try {
            Activity::event('server:domain.create')
                ->subject($server)
                ->property(['domain' => $domain->domain, 'cname_code' => $cnameCode, 'target_port' => $domain->target_port])
                ->log();
        } catch (\Throwable $e) {
            // Ignore activity logging errors
        }

        return $this->fractal->item($domain)
            ->transformWith($this->getTransformer(ServerDomainTransformer::class))
            ->toArray();
    }

    /**
     * Check/Verify connection status of custom domain DNS.
     */
    public function verify(GetDomainsRequest $request, Server $server, $domainId): JsonResponse
    {
        try {
            $domain = ServerDomain::where('server_id', $server->id)->find($domainId);
            if (!$domain) {
                return new JsonResponse([
                    'connected' => false,
                    'message' => 'This domain mapping does not belong to the current server.',
                ], JsonResponse::HTTP_NOT_FOUND);
            }

            $server->loadMissing('node');
            $nodeFqdn = strtolower(trim($server->node->fqdn ?? ''));
            $nodeIp = trim($server->node->ip ?? '');
            
            // Stable CNAME target per server
            $cnameCode = $domain->cname_code ?: ('srv-' . substr(md5('server_' . $server->id), 0, 6));
            $cnameTarget = strtolower($cnameCode ? "{$cnameCode}.{$nodeFqdn}" : $nodeFqdn);

            $isResolved = false;
            $details = 'DNS CNAME record not detected yet or pending DNS propagation.';

            // 1. Check CNAME records via PHP dns_get_record
            $dnsRecords = @dns_get_record($domain->domain, DNS_CNAME);
            if ($dnsRecords && is_array($dnsRecords)) {
                foreach ($dnsRecords as $rec) {
                    $target = strtolower(rtrim($rec['target'] ?? '', '.'));
                    // Match target CNAME, node FQDN, or subdomain node FQDN
                    if (
                        $target === rtrim($cnameTarget, '.') ||
                        $target === rtrim($nodeFqdn, '.') ||
                        ($nodeFqdn && str_contains($target, $nodeFqdn))
                    ) {
                        $isResolved = true;
                        $details = "Connected! CNAME record correctly points to {$target}";
                        break;
                    }
                }
            }

            // 2. Fallback: Check IP resolution if Cloudflare Proxy or A Record is used
            if (!$isResolved) {
                $resolvedIp = @gethostbyname($domain->domain);
                if ($resolvedIp && $resolvedIp !== $domain->domain) {
                    if ($nodeIp && $resolvedIp === $nodeIp) {
                        $isResolved = true;
                        $details = "Connected! Domain resolves to node IP ({$nodeIp}).";
                    } else {
                        // DNS resolves to an IP (e.g. Cloudflare proxy IP)
                        $isResolved = true;
                        $details = "Connected! Domain DNS is active (Resolves to {$resolvedIp}).";
                    }
                }
            }

            return new JsonResponse([
                'connected' => $isResolved,
                'message' => $details,
                'cname_target' => $cnameTarget,
            ]);
        } catch (\Throwable $e) {
            return new JsonResponse([
                'connected' => false,
                'message' => 'DNS check failed: ' . $e->getMessage(),
            ], JsonResponse::HTTP_OK);
        }
    }

    /**
     * Remove a custom domain mapping from a server.
     */
    public function delete(DeleteDomainRequest $request, Server $server, ServerDomain $domain): JsonResponse
    {
        if ($domain->server_id !== $server->id) {
            throw new DisplayException('This domain mapping does not belong to the current server.');
        }

        $domainName = $domain->domain;
        $domain->delete();

        try {
            Activity::event('server:domain.delete')
                ->subject($server)
                ->property(['domain' => $domainName])
                ->log();
        } catch (\Throwable $e) {
            // Ignore activity logging errors
        }

        return new JsonResponse([], JsonResponse::HTTP_NO_CONTENT);
    }
}
