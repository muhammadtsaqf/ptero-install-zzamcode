<?php

namespace Pterodactyl\Http\Controllers\Base;

use Illuminate\Http\Request;
use Pterodactyl\Models\Database;
use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Controllers\Controller;
use Illuminate\Contracts\Encryption\Encrypter;
use Pterodactyl\Contracts\Extensions\HashidsInterface;

class PhpMyAdminController extends Controller
{
    public function __construct(
        private Encrypter $encrypter,
        private HashidsInterface $hashids
    ) {
    }

    /**
     * Auto-login user to phpMyAdmin by rendering a same-origin auto-submitting form.
     */
    public function autologin(Request $request)
    {
        $databaseId = $request->input('database_id');
        $serverUuid = $request->input('server_uuid');

        if (!$databaseId || !$serverUuid) {
            abort(400, 'Missing required parameters.');
        }

        $numericId = is_numeric($databaseId) ? (int) $databaseId : ($this->hashids->decode($databaseId)[0] ?? null);

        /** @var Database|null $database */
        $database = Database::with(['host', 'server'])->find($numericId);

        if (!$database) {
            abort(404, 'Database not found.');
        }

        $user = $request->user();
        if (!$user || $user->cannot(Permission::ACTION_DATABASE_VIEW_PASSWORD, $database->server)) {
            abort(403, 'You do not have permission to access phpMyAdmin for this database.');
        }

        $password = htmlspecialchars($this->encrypter->decrypt($database->password), ENT_QUOTES, 'UTF-8');
        $username = htmlspecialchars($database->username, ENT_QUOTES, 'UTF-8');
        $pmaAutologinUrl = url('/phpmyadmin/autologin.php');

        return response()->make(<<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Connecting to phpMyAdmin...</title>
    <style>
        body {
            background-color: #0f172a;
            color: #ffffff;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            margin: 0;
        }
        .loader {
            text-align: center;
        }
        .spinner {
            border: 4px solid rgba(255, 255, 255, 0.1);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border-left-color: #06b6d4;
            animation: spin 1s linear infinite;
            margin: 0 auto 16px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="loader">
        <div class="spinner"></div>
        <p>Logging into phpMyAdmin...</p>
    </div>
    <form id="pma_form" action="{$pmaAutologinUrl}" method="post" style="display:none;">
        <input type="hidden" name="pma_username" value="{$username}" />
        <input type="hidden" name="pma_password" value="{$password}" />
        <input type="hidden" name="input_username" value="{$username}" />
        <input type="hidden" name="input_password" value="{$password}" />
    </form>
    <script>
        document.getElementById('pma_form').submit();
    </script>
</body>
</html>
HTML
        );
    }
}
