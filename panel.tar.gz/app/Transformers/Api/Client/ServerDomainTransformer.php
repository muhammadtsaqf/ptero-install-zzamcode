<?php

namespace Pterodactyl\Transformers\Api\Client;

use Pterodactyl\Models\ServerDomain;

class ServerDomainTransformer extends BaseClientTransformer
{
    /**
     * Return the resource name for the JSON API response.
     */
    public function getResourceName(): string
    {
        return ServerDomain::RESOURCE_NAME;
    }

    /**
     * Transform a ServerDomain model into a JSON API response array.
     */
    public function transform(ServerDomain $model): array
    {
        $node = $model->server ? $model->server->node : null;
        $nodeTarget = $node ? ($node->fqdn ?: $node->ip) : '';
        
        // Compute random/unique CNAME target string
        $cnameTarget = $model->cname_code ? "{$model->cname_code}.{$nodeTarget}" : $nodeTarget;

        return [
            'id' => $model->id,
            'server_id' => $model->server_id,
            'domain' => $model->domain,
            'cname_code' => $model->cname_code,
            'cname_target' => $cnameTarget,
            'target_port' => $model->target_port,
            'created_at' => $model->created_at->toIso8601String(),
            'updated_at' => $model->updated_at->toIso8601String(),
        ];
    }
}
