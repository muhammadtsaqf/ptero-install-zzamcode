<?php

namespace Pterodactyl\Transformers\Api\Client;

use Pterodactyl\Models\ServerDomain;

class ServerDomainTransformer extends BaseClientTransformer
{
    /**
     * Return the resource name for the JSON API response.
     */
    public function getResourceName(): string
    {
        return ServerDomain::RESOURCE_NAME;
    }

    /**
     * Transform a ServerDomain model into a JSON API response array.
     */
    public function transform(ServerDomain $model): array
    {
        return [
            'id' => $model->id,
            'server_id' => $model->server_id,
            'domain' => $model->domain,
            'target_port' => $model->target_port,
            'created_at' => $model->created_at->toIso8601String(),
            'updated_at' => $model->updated_at->toIso8601String(),
        ];
    }
}
